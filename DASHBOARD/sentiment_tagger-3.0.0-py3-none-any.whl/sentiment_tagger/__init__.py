"""sentiment_tagger — Indian political tweet sentiment tagger (8-class).

    pip install -e "path\\to\\sentiment_tagger_pkg"
    import sentiment_tagger as st
    st.tag_texts(["Modi ji zindabad", "mehngai ne kamar tod di"])

Same API as v0.2.0, so existing scripts keep working. What changed inside:

  * Ships a PRE-TRAINED model (no first-use training, no ~/.cache rebuild).
  * Adds a rule layer (sarcasm, government-scheme praise, personal complaints).
  * Adds per-class decision thresholds, which is what makes the rare classes
    fire at all - "No Sentiments" had 0.00 recall without them.
  * 8 labels instead of 7: adds "No Sentiments" for hashtag/URL-only rows.

API
---
    st.tag_texts(["...", "..."])          -> [{'label':..., 'confidence':...}, ...]
    st.tag_dataframe(df, text_column="Tweet Translate")
    st.tag_file("in.csv", "out.csv")      # csv / xlsx / pickle in, tagged copy out
    st.get_model()                        -> the loaded predictor

    # richer per-row detail (target + reason), new in this version:
    st.tag_texts_detailed(["..."])        -> [{'label','confidence','target','reason'}]

Labels
------
    Neutral, Positive, Negative, Pro BJP, Anti BJP, Pro Govt., Anti Govt., No Sentiments

    The old package used hyphens ("Pro-BJP", "Pro-Govt"). If downstream code
    depends on those, pass legacy_labels=True to any function, or call
    st.to_legacy_label(x).

CLI
---
    sentiment-tag "in.csv" --output "out.csv"
    python -m sentiment_tagger "in.csv" --output "out.csv"
"""
from __future__ import annotations

import argparse
import functools
from pathlib import Path
from typing import Iterable, Optional

import pandas as pd

from ._predictor import SentimentPredictor, get_predictor

__all__ = [
    "get_model", "tag_texts", "tag_texts_detailed", "tag_dataframe", "tag_file",
    "to_legacy_label", "LABELS", "main",
]
__version__ = "3.0.0"

LABELS = ["Anti BJP", "Anti Govt.", "Negative", "Neutral",
          "No Sentiments", "Positive", "Pro BJP", "Pro Govt."]

# "Tweet Translate" first - it is what the current pipeline actually produces.
TEXT_COLUMN_CANDIDATES = [
    "Tweet Translate", "Tweet Text", "tweet_text", "text", "Text", "tweet", "Tweet",
]

_LEGACY = {
    "Pro BJP": "Pro-BJP",
    "Anti BJP": "Anti-BJP",
    "Pro Govt.": "Pro-Govt",
    "Anti Govt.": "Anti-Govt",
    "No Sentiments": "Neutral",   # the 7-class scheme had no such label
}


def to_legacy_label(label: str) -> str:
    """Map an 8-class label back to the old 7-class hyphenated scheme."""
    return _LEGACY.get(label, label)


def _normalize(value: object) -> str:
    return " ".join(str(value).split()) if pd.notna(value) else ""


@functools.lru_cache(maxsize=1)
def get_model() -> SentimentPredictor:
    """Return the bundled pre-trained predictor (loaded once, then reused)."""
    p = get_predictor()
    if not p.is_loaded():
        raise RuntimeError("Model artifacts missing from the installed package.")
    return p


def tag_texts(texts: Iterable[str], legacy_labels: bool = False) -> list[dict]:
    """Tag a list of strings. Returns [{'label':..., 'confidence':...}, ...]."""
    model = get_model()
    out = []
    for t in texts:
        s = _normalize(t)
        if not s:
            out.append({"label": "No Sentiments", "confidence": 0.99})
            continue
        r = model.predict(s)
        lab = to_legacy_label(r["sentiment"]) if legacy_labels else r["sentiment"]
        out.append({"label": lab, "confidence": round(float(r["confidence"]), 4)})
    return out


def tag_texts_detailed(texts: Iterable[str], legacy_labels: bool = False) -> list[dict]:
    """Like tag_texts, but also returns the target entity and the reason."""
    model = get_model()
    out = []
    for t in texts:
        s = _normalize(t)
        if not s:
            out.append({"label": "No Sentiments", "confidence": 0.99,
                        "target": "None", "reason": "Empty or missing text."})
            continue
        r = model.predict(s)
        lab = to_legacy_label(r["sentiment"]) if legacy_labels else r["sentiment"]
        out.append({"label": lab, "confidence": round(float(r["confidence"]), 4),
                    "target": r["target"], "reason": r["reason"]})
    return out


def _find_text_column(df: pd.DataFrame, requested: Optional[str]) -> str:
    if requested:
        if requested not in df.columns:
            raise ValueError(f"Column '{requested}' not found. Available: {list(df.columns)}")
        return requested
    for c in TEXT_COLUMN_CANDIDATES:
        if c in df.columns:
            return c
    raise ValueError(
        f"Could not auto-detect a text column. Pass text_column=. Available: {list(df.columns)}")


def tag_dataframe(df: pd.DataFrame, text_column: Optional[str] = None,
                  legacy_labels: bool = False, detailed: bool = False) -> pd.DataFrame:
    """Add Final_Sentiment and Socre columns to a DataFrame.

    'Socre' is kept (misspelling and all) so existing scripts keep working.
    'Score' is added alongside it with the same values.
    """
    col = _find_text_column(df, text_column)
    fn = tag_texts_detailed if detailed else tag_texts
    results = fn(df[col].tolist(), legacy_labels=legacy_labels)
    out = df.copy()
    out["Final_Sentiment"] = [r["label"] for r in results]
    out["Socre"] = [r["confidence"] for r in results]   # original (typo'd) name
    out["Score"] = out["Socre"]                          # correctly spelled alias
    if detailed:
        out["Target"] = [r["target"] for r in results]
        out["Reason"] = [r["reason"] for r in results]
    return out


def _read_any(path: Path) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix in {".xlsx", ".xls"}:
        try:
            return pd.read_excel(path)
        except Exception:
            pass  # some exports are CSV with an .xlsx name
    if suffix in {".pickle", ".pkl"}:
        obj = pd.read_pickle(path)
        return obj if isinstance(obj, pd.DataFrame) else pd.DataFrame(obj)
    return pd.read_csv(path, encoding="utf-8-sig", low_memory=False)


def tag_file(input_file, output_file=None, text_column: Optional[str] = None,
             legacy_labels: bool = False, detailed: bool = False) -> Path:
    """Read a csv/xlsx/pickle file, tag it, write a tagged copy, return the output path."""
    in_path = Path(input_file)
    df = _read_any(in_path)
    tagged = tag_dataframe(df, text_column, legacy_labels=legacy_labels, detailed=detailed)
    out_path = Path(output_file) if output_file else in_path.with_name(in_path.stem + "_tagged.csv")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    if out_path.suffix.lower() in {".xlsx", ".xls"}:
        tagged.to_excel(out_path, index=False)
    else:
        tagged.to_csv(out_path, index=False, encoding="utf-8-sig")
    return out_path


def main(argv: Optional[list] = None) -> None:
    ap = argparse.ArgumentParser(prog="sentiment-tag",
                                 description="Tag tweet sentiment (self-contained, pre-trained).")
    ap.add_argument("input", help="Input file (.csv / .xlsx / .pickle)")
    ap.add_argument("--output", default=None, help="Output path (default: <input>_tagged.csv)")
    ap.add_argument("--text-column", default=None, help="Text column (auto-detected if omitted)")
    ap.add_argument("--legacy-labels", action="store_true",
                    help="Emit the old 7-class hyphenated labels (Pro-BJP, Pro-Govt, ...)")
    ap.add_argument("--detailed", action="store_true", help="Also write Target and Reason columns")
    args = ap.parse_args(argv)

    print(f"sentiment_tagger v{__version__}  thresholds={get_model().thresholds}")
    out = tag_file(args.input, args.output, args.text_column,
                   legacy_labels=args.legacy_labels, detailed=args.detailed)
    df = _read_any(out)
    print(f"Done. Wrote {out}")
    print(df["Final_Sentiment"].value_counts().to_string())
    floor = (df["Socre"] == 0.70).sum()
    print(f"\nRows at floor confidence 0.70 (model unsure): {floor:,} "
          f"({100*floor/len(df):.1f}%) - review these first")


if __name__ == "__main__":
    main()
