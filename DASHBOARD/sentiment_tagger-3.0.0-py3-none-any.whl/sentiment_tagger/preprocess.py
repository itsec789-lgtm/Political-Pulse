"""
Text Preprocessing & Normalization Module for Multilingual Sentiment & Political-Stance Classifier.
Handles Devanagari Hindi, Romanized Hindi (Hinglish), and English social media posts.
"""

import re
import html

# Pre-compiled regular expressions for speed
URL_PATTERN = re.compile(r"https?://\S+|www\.\S+", re.IGNORECASE)
MENTION_PATTERN = re.compile(r"@\w+", re.UNICODE)
HASHTAG_PATTERN = re.compile(r"#\w+", re.UNICODE)
MULTI_SPACE_PATTERN = re.compile(r"\s+")
SPECIAL_CHARS_PATTERN = re.compile(r"[^\w\s\u0900-\u097F]", re.UNICODE)

DEVANAGARI_CONSONANTS = {
    'क': 'k', 'ख': 'kh', 'ग': 'g', 'घ': 'gh', 'ङ': 'ng',
    'च': 'ch', 'छ': 'chh', 'ज': 'j', 'झ': 'jh', 'ञ': 'ny',
    'ट': 't', 'ठ': 'th', 'ड': 'd', 'ढ': 'dh', 'ण': 'n',
    'त': 't', 'थ': 'th', 'द': 'd', 'ध': 'dh', 'न': 'n',
    'प': 'p', 'फ': 'ph', 'ब': 'b', 'भ': 'bh', 'म': 'm',
    'य': 'y', 'र': 'r', 'ल': 'l', 'व': 'v', 'श': 'sh', 'ष': 'sh', 'स': 's', 'ह': 'h',
    'क़': 'q', 'ख़': 'kh', 'ग़': 'gh', 'ज़': 'z', 'ड़': 'd', 'ढ़': 'dh', 'फ़': 'f'
}

DEVANAGARI_VOWELS = {
    'अ': 'a', 'आ': 'aa', 'इ': 'i', 'ई': 'ee', 'उ': 'u', 'ऊ': 'oo', 'ऋ': 'ri',
    'ए': 'e', 'ऐ': 'ai', 'ओ': 'o', 'औ': 'au'
}

DEVANAGARI_MATRAS = {
    'ा': 'aa', 'ि': 'i', 'ी': 'ee', 'ु': 'u', 'ू': 'oo', 'ृ': 'ri',
    'े': 'e', 'ै': 'ai', 'ो': 'o', 'ौ': 'au',
    'ं': 'n', 'ँ': 'n', 'ः': 'h'
}


def devanagari_to_roman(text: str) -> str:
    """
    Phonetically transliterates Devanagari Hindi text to Roman Hindi so it aligns
    with Romanized Hindi social media conventions in the training dataset.
    """
    if not text:
        return ""
    
    res = []
    chars = list(text)
    n = len(chars)
    i = 0
    while i < n:
        c = chars[i]
        if c in DEVANAGARI_CONSONANTS:
            base = DEVANAGARI_CONSONANTS[c]
            if i + 1 < n:
                nxt = chars[i + 1]
                if nxt == '्':  # Virama / halant
                    res.append(base)
                    i += 2
                    continue
                elif nxt in DEVANAGARI_MATRAS:
                    res.append(base + DEVANAGARI_MATRAS[nxt])
                    i += 2
                    continue
                elif nxt in DEVANAGARI_CONSONANTS:
                    res.append(base + 'a')
                else:
                    res.append(base)
            else:
                res.append(base)
        elif c in DEVANAGARI_VOWELS:
            res.append(DEVANAGARI_VOWELS[c])
        elif c in DEVANAGARI_MATRAS:
            res.append(DEVANAGARI_MATRAS[c])
        elif c == '।':
            res.append('.')
        else:
            res.append(c)
        i += 1
    return "".join(res)


def is_no_sentiment_candidate(raw_text: str) -> bool:
    """
    Identifies if the text matches the 'No Sentiments' definition:
    - Empty or whitespace only
    - Only a URL
    - Only hashtags
    - Only mentions
    - Corrupted/too short without meaningful words (e.g., 'rt', '...', single symbols)
    """
    if not raw_text or not isinstance(raw_text, str):
        return True
    
    text = raw_text.strip()
    if len(text) == 0:
        return True

    # Strip URLs
    text_without_urls = URL_PATTERN.sub("", text).strip()
    if len(text_without_urls) == 0:
        return True

    # Strip mentions and hashtags
    text_no_social = MENTION_PATTERN.sub("", text_without_urls)
    text_no_social = HASHTAG_PATTERN.sub("", text_no_social).strip()
    if len(text_no_social) == 0:
        return True

    # Remove non-word characters and whitespace
    words_only = SPECIAL_CHARS_PATTERN.sub("", text_no_social).strip()
    words = words_only.split()
    
    if len(words) == 0:
        return True
    if len(words) == 1 and (words[0].lower() in {"rt", "via", "dm"} or len(words[0]) <= 2):
        return True

    return False


def clean_text(text: str) -> str:
    """
    Cleans and normalizes multilingual social media text:
    1. Unescapes HTML entities
    2. Normalizes URLs and mentions
    3. Retains hashtags as plain words
    4. Transliterates Devanagari script to Roman Hindi
    5. Standardizes Hinglish spellings (e.g. bjp, sarkar, hai, mein)
    """
    if not text or not isinstance(text, str):
        return ""

    # Unescape HTML entities
    text = html.unescape(text)

    # Transliterate any Devanagari characters to Roman Hindi phonetics
    if re.search(r"[\u0900-\u097F]", text):
        text = devanagari_to_roman(text)

    # Normalize URLs
    text = URL_PATTERN.sub(" http_url ", text)

    # Normalize mentions
    text = MENTION_PATTERN.sub(" user_mention ", text)

    # Extract hashtag text
    text = re.sub(r"#(\w+)", r" \1 ", text)

    # Replace special punctuation
    text = text.replace("’", "'").replace("‘", "'").replace("“", '"').replace("”", '"')
    text = text.replace("—", " ").replace("–", " ").replace("…", " ")

    # Lowercase
    text = text.lower()

    # Normalize phonetic Hinglish variations to dataset vocabulary
    text = re.sub(r"\bbjp\b", "bhaajapa", text)
    text = re.sub(r"\bbhajpa\b", "bhaajapa", text)
    text = re.sub(r"\bsarkar\b", "sarkaar", text)
    text = re.sub(r"\bsarakaar\b", "sarkaar", text)
    text = re.sub(r"\bmein\b", "main", text)
    text = re.sub(r"\bmen\b", "main", text)
    text = re.sub(r"\bhai\b", "he", text)
    text = re.sub(r"\bki\b", "kii", text)
    text = re.sub(r"\bviphal\b", "vifal", text)
    text = re.sub(r"\bphailed\b", "failed", text)

    # Collapse whitespace
    text = MULTI_SPACE_PATTERN.sub(" ", text).strip()

    return text
