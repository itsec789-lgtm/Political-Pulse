"""
Predictor for Multilingual Sentiment & Political-Stance Classifier.
Bundled model artifacts ship inside this package (sentiment/models/).
"""

import os
import re
import json
import joblib
from typing import Dict, Any, Optional

from .preprocess import clean_text, is_no_sentiment_candidate

MODELS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models")
VECTORIZER_PATH = os.path.join(MODELS_DIR, "vectorizer.joblib")
MODEL_PATH = os.path.join(MODELS_DIR, "sentiment_model.joblib")
THRESHOLDS_PATH = os.path.join(MODELS_DIR, "thresholds.json")

COMMEMORATION_WORDS = {
    "naman", "shradhanjali", "jayanti", "badhai", "shubhkamnayein",
    "diwas", "jyoti-jyot", "divas", "birthday", "anniversary", "congratulations",
    "mubarak", "greetings", "salute", "shat-shat"
}

TRAGIC_WORDS = {
    "shok", "dukhad", "nidhan", "hadsa", "rip", "om shanti", "condolences",
    "condolence", "demise", "maut", "tragic", "death", "mar", "ghayal"
}

BJP_KEYWORDS = {
    "bjp", "bhaajapa", "bhajpa", "modi", "narendra modi", "amit shah",
    "yogi", "adityanath", "jp nadda", "bhartiya janata party"
}

GOVT_KEYWORDS = {
    "sarkaar", "sarkar", "government", "pradhanmantri", "pm", "cm",
    "mantralaya", "vibhaag", "yojana", "scheme", "shasan", "kendra sarkar"
}


class SentimentPredictor:
    def __init__(self, vectorizer_path: str = VECTORIZER_PATH, model_path: str = MODEL_PATH):
        self.vectorizer_path = vectorizer_path
        self.model_path = model_path
        self.vectorizer = None
        self.model = None
        self.classes = []
        self._load_artifacts()

    def _load_artifacts(self):
        if os.path.exists(self.vectorizer_path) and os.path.exists(self.model_path):
            self.vectorizer = joblib.load(self.vectorizer_path)
            self.model = joblib.load(self.model_path)
            self.classes = list(self.model.classes_)
        else:
            self.vectorizer = None
            self.model = None
            self.classes = []
        # Per-class decision thresholds for the rare classes. Without these the
        # model almost never predicts them (No Sentiments recall was 0.00).
        self.thresholds = {}
        if os.path.exists(THRESHOLDS_PATH):
            try:
                with open(THRESHOLDS_PATH, "r", encoding="utf-8") as f:
                    self.thresholds = json.load(f).get("thresholds", {}) or {}
            except Exception:
                self.thresholds = {}

    def is_loaded(self) -> bool:
        return self.vectorizer is not None and self.model is not None

    def _extract_target_and_reason(self, raw_text: str, cleaned_text: str, sentiment: str):
        lower_raw = raw_text.lower()
        words = set(re.findall(r"\w+", lower_raw))

        if sentiment == "No Sentiments":
            return "None", "The content does not contain enough meaningful text to determine sentiment."
        if sentiment == "Pro BJP":
            return "BJP", "The text supports, praises, promotes, or celebrates BJP or its political representatives."
        if sentiment == "Anti BJP":
            return "BJP", "The text criticizes or opposes BJP, its leaders, campaign, or political conduct."
        if sentiment == "Pro Govt.":
            scheme_match = re.search(r"([\w\s]+(?:yojana|scheme|mission|aawas|kisan|ayushman))", lower_raw, re.IGNORECASE)
            target = "Government policy or administration"
            if scheme_match:
                candidate = scheme_match.group(1).strip().title()
                if 3 < len(candidate) < 40:
                    target = f"{candidate} scheme"
            return target, "The text appreciates a government programme, public service, development work, or official performance."
        if sentiment == "Anti Govt.":
            return "Government or public administration", "The text criticizes government policy, administration, public services, or official performance."
        if sentiment == "Positive":
            if any(w in words for w in COMMEMORATION_WORDS):
                return "Personal commemoration or occasion", "The text conveys greetings, respect, remembrance, or good wishes for a personal occasion."
            return "General subject", "The text expresses appreciation, congratulations, hope, pride, gratitude, or another positive view."
        if sentiment == "Negative":
            if any(w in words for w in TRAGIC_WORDS):
                return "Bereavement or tragic event", "The text expresses grief, condolences, loss, or concern about a tragic event."
            return "General subject", "The text expresses criticism, dissatisfaction, concern, grief, or another negative view without a BJP or government target."
        if sentiment == "Neutral":
            if any(w in words for w in BJP_KEYWORDS):
                return "BJP", "The text mentions BJP but does not express a sufficiently clear supportive or critical stance."
            if any(w in words for w in GOVT_KEYWORDS):
                return "Government or public administration", "The text reports or mentions government activity without a sufficiently clear opinion."
            return "General subject", "The text is meaningful but does not express a clear positive or negative stance."
        return "General subject", "The text conveys standard context."

    def _check_contextual_rules(self, raw_text: str, cleaned_text: str) -> Optional[Dict[str, Any]]:
        lower_raw = raw_text.lower()

        is_sarcastic_intro = bool(re.search(r"(?:वाह|wah|shabaash|great job|kya baat|kya shaanadaar|kya baat hai)", lower_raw))
        is_negative_outcome = bool(re.search(r"(?:महंगाई|mehangai|बिजली.*नहीं|bijli.*nahi|water|पानी|dhokha|broken|naheen|vifal|विफल|तीन दिन से|problem|kharab)", lower_raw))
        if is_sarcastic_intro and is_negative_outcome:
            if re.search(r"(?:मोदी|modi|bjp|bhaajapa|amit shah|yogi)", lower_raw):
                return {"sentiment": "Anti BJP", "confidence": 0.96, "target": "BJP",
                        "reason": "The apparent praise is sarcastic and criticizes BJP or its political leadership."}
            else:
                return {"sentiment": "Anti Govt.", "confidence": 0.96, "target": "Government",
                        "reason": "The apparent praise is sarcastic and criticizes the government over public services or governance."}

        is_scheme = bool(re.search(r"(?:योजना|yojana|scheme|mission|ayushman|aawas|kisan samman|swasthya)", lower_raw))
        is_benefit = bool(re.search(r"(?:सहायता|sahayata|labh|benefit|ilaaj|इलाज|madad|मदद|faayda|फायदा|raahat|सुविधा)", lower_raw))
        has_party = bool(re.search(r"\b(?:bjp|bhaajapa|party|dal)\b", cleaned_text))
        if is_scheme and is_benefit and not has_party:
            scheme_candidate = "Ayushman Bharat scheme" if "ayushman" in lower_raw or "आयुष्मान" in raw_text else "Government scheme"
            return {"sentiment": "Pro Govt.", "confidence": 0.94, "target": scheme_candidate,
                    "reason": "The text appreciates the benefits provided by a government scheme."}

        is_inconvenience = bool(re.search(r"(?:लेट होने से|let hone|delay|परेशानी|pareshaani|pareshaan|takleef|frustrat|घंटे लेट)", lower_raw))
        has_political_target = bool(re.search(r"\b(?:bjp|bhaajapa|sarkaar|sarkar|government|modi)\b", cleaned_text))
        if is_inconvenience and not has_political_target:
            target = "Train delay" if ("ट्रेन" in raw_text or "train" in lower_raw) else "Personal inconvenience"
            return {"sentiment": "Negative", "confidence": 0.96, "target": target,
                    "reason": "The author expresses frustration caused by a delay or personal inconvenience."}

        return None

    def predict(self, raw_text: str) -> Dict[str, Any]:
        if is_no_sentiment_candidate(raw_text):
            return {"sentiment": "No Sentiments", "confidence": 0.99, "target": "None",
                    "reason": "The content contains only hashtags, URLs, mentions, or insufficient text to determine meaning."}

        cleaned = clean_text(raw_text)
        if not cleaned or len(cleaned.strip()) <= 2:
            return {"sentiment": "No Sentiments", "confidence": 0.99, "target": "None",
                    "reason": "The content does not contain enough meaningful text to determine sentiment."}

        rule_result = self._check_contextual_rules(raw_text, cleaned)
        if rule_result is not None:
            return rule_result

        if not self.is_loaded():
            self._load_artifacts()
            if not self.is_loaded():
                raise RuntimeError("Model artifacts not found inside the installed package.")

        vec = self.vectorizer.transform([cleaned])
        probs = self.model.predict_proba(vec)[0]
        max_idx = int(probs.argmax())

        # A rare class wins if it clears its own threshold, even without the
        # highest probability. If several clear, the one furthest above its
        # threshold wins, so the classes don't fight each other.
        best_margin = None
        for cls_name, thr in self.thresholds.items():
            if cls_name not in self.classes:
                continue
            j = self.classes.index(cls_name)
            if probs[j] >= thr:
                margin = probs[j] - thr
                if best_margin is None or margin > best_margin:
                    best_margin = margin
                    max_idx = j

        predicted_sentiment = str(self.classes[max_idx])
        raw_conf = float(probs[max_idx])
        calibrated_conf = round(min(0.99, max(0.70, raw_conf)), 2)

        target, reason = self._extract_target_and_reason(raw_text, cleaned, predicted_sentiment)

        return {"sentiment": predicted_sentiment, "confidence": calibrated_conf, "target": target, "reason": reason}

    def predict_json(self, raw_text: str) -> str:
        return json.dumps(self.predict(raw_text), indent=2, ensure_ascii=False)


_PREDICTOR_INSTANCE: Optional[SentimentPredictor] = None

def get_predictor() -> SentimentPredictor:
    global _PREDICTOR_INSTANCE
    if _PREDICTOR_INSTANCE is None:
        _PREDICTOR_INSTANCE = SentimentPredictor()
    return _PREDICTOR_INSTANCE
