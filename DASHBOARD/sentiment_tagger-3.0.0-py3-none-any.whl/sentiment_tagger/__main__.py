from sentiment_tagger import main

if __name__ == "__main__":
    main()
